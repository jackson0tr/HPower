import BecomeApartner from "@/components/partners/BecomeApartner";
import React from "react";
const page = () => {
  return (
    <div className="">
      <BecomeApartner />
    </div>
  );
};

export default page;
